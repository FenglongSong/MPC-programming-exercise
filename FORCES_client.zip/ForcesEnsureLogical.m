% Converts the input argument of various types into its logical value
% (or false if not possible). For internal use only.
%
%   
% This file is part of the FORCESPRO client software for Matlab.
% (c) embotech AG, 2013-20, Zurich, Switzerland. All rights reserved.
