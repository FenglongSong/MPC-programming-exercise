% Call a function with as many arguments as it accepts and none more.
