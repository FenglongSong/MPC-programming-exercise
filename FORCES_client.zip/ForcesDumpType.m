%ForcesDumpType specifies what information should be contained in a dump.
%
% Currently supported types:
% 
%     LegacyDumpGeneratedC:  Only generated C code of formulation and codeoptions
%     DumpSymbolics:         Full symbolic formulation and codeoptions
%   
% This file is part of the FORCESPRO client software for Matlab.
% (c) embotech AG, 2013-2021, Zurich, Switzerland. All rights reserved.