% Creates a string representing the given symbolic expression which can be
% imported using ForcesDeserializeSymbolicExpression.
% For internal use only.
%   
% This file is part of the FORCESPRO client software for Matlab.
% (c) embotech AG, 2013-2021, Zurich, Switzerland. All rights reserved.
