server = 'https://forces.embotech.com'
