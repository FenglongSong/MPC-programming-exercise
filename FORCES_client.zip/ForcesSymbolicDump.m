% Dumps a FORCESPRO problem formulation and/or problem instance into a file 
% to allow to exactly reproduce the issues with the exported code.
% For internal use only.
%   
% This file is part of the FORCESPRO client software for Matlab.
% (c) embotech AG, 2013-2021, Zurich, Switzerland. All rights reserved.
