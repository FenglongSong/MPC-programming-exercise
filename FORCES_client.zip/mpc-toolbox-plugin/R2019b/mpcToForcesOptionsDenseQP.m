%% FORCESPRO "mpc-toolbox-plugin" Dense QP utility

%   Author(s): Rong Chen, MathWorks Inc.
%
%   Copyright 2019-2021 The MathWorks, Inc.
