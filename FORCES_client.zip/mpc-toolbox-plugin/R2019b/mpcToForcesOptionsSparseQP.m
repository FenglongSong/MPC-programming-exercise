%% FORCESPRO "mpc-toolbox-plugin" Sparse QP utility

%   Author(s): Rong Chen, MathWorks Inc.
%
%   Copyright 2019-2021 The MathWorks, Inc.
