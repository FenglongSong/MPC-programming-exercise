function [maskdisplay, port] = forces_block_UpdateInport(blk,AvailableBlocks,type_in_mask,type_in_block,index,name,port,mpcport,maskdisplay)
%% FORCESPRO "mpc-toolbox-plugin" Simulink block utility

%   Author(s): Rong Chen, MathWorks Inc.
%
%   Copyright 2019-2021 The MathWorks, Inc.
