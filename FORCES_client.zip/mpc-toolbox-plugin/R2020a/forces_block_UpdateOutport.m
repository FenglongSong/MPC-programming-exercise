function [maskdisplay, port] = forces_block_UpdateOutport(blk,AvailableBlocks,type_out_mask,type_out_block,index,name,port,mpcport,maskdisplay)
%% FORCESPRO "mpc-toolbox-plugin" Simulink block utility

%   Author(s): Rong Chen, MathWorks Inc.
%
%   Copyright 2019-2021 The MathWorks, Inc.
