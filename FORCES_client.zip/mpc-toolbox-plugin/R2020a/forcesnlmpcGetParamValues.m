function params = forcesnlmpcGetParamValues(coredata,onlinedata,x,lastMV,md,ref,mvTarget,para)
%% FORCESPRO "mpc-toolbox-plugin" simulation utility

%   Author(s): Rong Chen, MathWorks Inc.
%
%   Copyright 2019-2021 The MathWorks, Inc.
