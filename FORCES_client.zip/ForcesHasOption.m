% Returns whether a given codeoption has been specified.
% For internal use only.
%   
% This file is part of the FORCESPRO client software for Matlab.
% (c) embotech AG, 2013-2021, Zurich, Switzerland. All rights reserved.
